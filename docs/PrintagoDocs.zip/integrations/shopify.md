---
sidebar_position: 1
title: Shopify 
---

# Shopify Integration

Connect your Shopify store to Printago for automated order processing.

## Features

- Automatic order import
- Inventory synchronization
- Order status updates
- Product mapping to SKUs

## Status

Coming soon. Join our [Discord](https://discord.gg/RCFA2u99De) for updates.
