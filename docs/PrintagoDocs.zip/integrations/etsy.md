---
sidebar_position: 2
title: Etsy
---

# Etsy Integration

Connect your Etsy shop to Printago for automated order processing.

## Features

- Automatic order import

## Status

Coming soon. Join our [Discord](https://discord.gg/RCFA2u99De) for updates.
