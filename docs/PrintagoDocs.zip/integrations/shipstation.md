---
sidebar_position: 3
title: Shipstation
---

# ShipStation Integration

Connect Printago with Shipstation as an order source

## Features

- Automatic order import

## Status

Coming soon. Join our [Discord](https://discord.gg/RCFA2u99De) for updates.
