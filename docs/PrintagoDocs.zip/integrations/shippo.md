---
sidebar_position: 4
title: Shippp
---

# Shippo Integration

Connect Printago with Shippo as an order source

## Features

- Automatic order import

## Status

Coming soon. Join our [Discord](https://discord.gg/RCFA2u99De) for updates.
